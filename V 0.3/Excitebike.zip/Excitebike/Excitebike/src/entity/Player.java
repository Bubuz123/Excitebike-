/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import excitebike.Controlli;
import excitebike.Pannello;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.image.BufferedImage;
/**
 *
 * @author Newer
 */
public class Player extends Entity{
    Pannello pannello;
    Controlli controlli;
    
    public final int screenX;
    public final int screenY;

    public Player(Pannello pannello, Controlli controlli) {
        this.pannello = pannello;
        this.controlli = controlli;
        
        screenX = pannello.larghezzaschermo/2 - (pannello.Tilesfinali/2);
        screenY = pannello.altezzaschermo/2 - (pannello.Tilesfinali/2); //per mettere il giocatore al centro
        
        hitbox = new Rectangle(0, 0, pannello.Tilesfinali, pannello.Tilesfinali); //invece di pannello.Tilesfinali metti 32 per collisioni + piccole
        
        setDefault();
        getImage();
    }
    
    public void setDefault()
    {
        worldx = pannello.Tilesfinali * 5; //x iniziale (sul map01.txt)
        worldy = pannello.Tilesfinali * 9; //y iniziale
        speed = 4;
        direction = "destra";
    }
    
    public void getImage()
    {
        try {
            //cambia i vari test con gli sprite (su/giu/destra/sinistra) e le loro animazioni (nel 2)
            //qua assegni ad ogni sprite del player il suo file (mettilo nel package Player dentro res)
            su1 = ImageIO.read(getClass().getResourceAsStream("/player/test.png"));
            su2 = ImageIO.read(getClass().getResourceAsStream("/player/test2.png"));
            giu1 = ImageIO.read(getClass().getResourceAsStream("/player/test.png"));
            giu2 = ImageIO.read(getClass().getResourceAsStream("/player/test2.png"));
            sinistra1 = ImageIO.read(getClass().getResourceAsStream("/player/test.png"));
            sinistra2 = ImageIO.read(getClass().getResourceAsStream("/player/test2.png"));
            destra1 = ImageIO.read(getClass().getResourceAsStream("/player/test.png"));
            destra2 = ImageIO.read(getClass().getResourceAsStream("/player/test2.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void aggiorna()
    {
        /*if(controlli.supremuto == true || controlli.giupremuto == true || controlli.sinistrapremuto == true || controlli.destrapremuto == true)
        {
            
        }*/ //metti tutto qui se vuoi che si aggiorni lo sprite solo quando un tasto è premuto
        if (controlli.supremuto == true) {
            direction = "su";
        } else if (controlli.giupremuto == true) {
            direction = "giu";
        } else if (controlli.sinistrapremuto == true) {
            direction = "sinistra";
        } else if (controlli.destrapremuto == true) {
            direction = "destra"; 
        }
        
        collision = false;
        pannello.collisioni.controllaTile(this);
        
        //se rimane false si può muovere
        if(collision == false)
        {
            if(controlli.supremuto || controlli.giupremuto || controlli.sinistrapremuto || controlli.destrapremuto)
            {
                switch(direction){
                case "su":
                    worldy -= speed;
                    break;
                case "giu":
                    worldy += speed;
                    break;
                case "sinistra":
                    worldx += speed;
                    break;
                case "destra":
                    worldx -= speed;
                    break;
            }
            }
        }
        contSprite++;
        if(contSprite > 10) //cambia il 10 per rallentare animazione
        {
            if(numSprite == 1)
            {
                numSprite = 2;
            }
            else if(numSprite == 2)
            {
                numSprite = 1;
            }
            contSprite = 0;
        }
    }
    
    public void draw(Graphics2D g2)
    {
        BufferedImage image = null;
        
        switch(direction)
        {
            case "su":
                if(numSprite == 1)
                {
                    image = su1;
                }
                if(numSprite == 2)
                {
                    image = su2;
                }
                break;
            case "giu":
                if(numSprite == 1)
                {
                    image = giu1;
                }
                if(numSprite == 2)
                {
                    image = giu2;
                }
                break;
            case "sinistra":
                if(numSprite == 1)
                {
                    image = sinistra1;
                }
                if(numSprite == 2)
                {
                    image = sinistra2;
                }
                break;
            case "destra":
                if(numSprite == 1)
                {
                    image = destra1;
                }
                if(numSprite == 2)
                {
                    image = destra2;
                }
                break;
        }
        g2.drawImage(image, screenX, screenY, pannello.Tilesfinali, pannello.Tilesfinali, null);
    }
}
