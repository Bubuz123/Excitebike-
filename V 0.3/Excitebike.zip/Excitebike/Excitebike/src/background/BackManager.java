/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package background;

import excitebike.Pannello;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.Buffer;
import javax.imageio.ImageIO;
/**
 *
 * @author Acer
 */
public class BackManager {
    Pannello p;
    public Background[] background;
    public int grandezzamappa[][];
    
    public BackManager (Pannello p)
    {
        this.p=p;
        background = new Background[10];
        grandezzamappa = new int[p.maxWorldCol][p.maxWorldRig];
        getBackImage();
        creamappa("/maps/map01.txt");
    }
    public void getBackImage()
    {
        try{
            //qua i tiles della mappa
            background[0] = new Background();
            background[0].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/road.png"));
            
            background[1] = new Background();
            background[1].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/wall.png"));
            background[1].collision = true;
            
        }catch(IOException e){
        e.printStackTrace();
    }
    }
    public void creamappa(String filePath)
    {
        try{
            InputStream is=getClass().getResourceAsStream(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            int col=0;
            int row=0;
            while(col <p.maxWorldCol && row<p.maxWorldRig){
                String line= br.readLine();
                while(col <p.maxWorldCol){
                    String numbers[]=line.split(" ");
                    
                    int num=Integer.parseInt(numbers[col]);
                    
                    grandezzamappa[col][row]=num;
                    col++;
                }
                if(col == p.maxWorldCol){
                    col = 0;
                    row++;
                }
                
            }
            br.close();
        }catch(Exception e)
        {
            
        }
    }
    public void disegna(Graphics2D g2){
        //g2.drawImage(background[0].image, 0, 0, p.Tilesfinali, p.Tilesfinali, null);
        //g2.drawImage(background[1].image, 48, 0, p.Tilesfinali, p.Tilesfinali, null);
       
        int col = 0;
        int row=0; 
        
        while(col <p.maxWorldCol && row<p.maxWorldRig )
        {
            int numap = grandezzamappa[col][row];
            
            int worldx = col * p.Tilesfinali;
            int worldy = row * p.Tilesfinali;
            int screenx = worldx - p.giocatore.worldx + p.giocatore.screenX;
            int screeny = worldy - p.giocatore.worldy + p.giocatore.screenY;
            
            //disegna solo i tiles che si vedono per non rallentare (+ 1 o 2 tiles per non vedere parti nere)
            if(worldx + (p.Tilesfinali*2) > p.giocatore.worldx - p.giocatore.screenX &&
               worldx - (p.Tilesfinali*2) < p.giocatore.worldx + p.giocatore.screenX &&
               worldy + (p.Tilesfinali*2) > p.giocatore.worldy - p.giocatore.screenY &&
               worldy - (p.Tilesfinali*2) < p.giocatore.worldy + p.giocatore.screenY)
            {
                g2.drawImage(background[numap].image, screenx, screeny, p.Tilesfinali, p.Tilesfinali, null);
            }
            col++;
            if(col == p.maxWorldCol){
                col=0;
                row++;
            }
        }
    }

    
}
