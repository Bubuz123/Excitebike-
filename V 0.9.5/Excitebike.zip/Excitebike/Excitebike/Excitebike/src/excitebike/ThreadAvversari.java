/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excitebike;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Newer
 */
public class ThreadAvversari extends Thread {

    Pannello p;
    Boolean b = false;
    int ultimo = 4;

    public ThreadAvversari(Pannello p) {
        this.p = p;
    }

    @Override
    public void run() {
        do {
            System.out.println(p.npc[2].xpersa);
            if (p.gamestate == p.statogioca) {
                if (p.npc[0].xpersa >= 1500 && b == false && ultimo!=0) {
                    b = true;
                    ultimo = 0;
                    p.npc[0].worldx = p.giocatore.screenX + 700;
                    p.npc[0].xpersa = 0;
                    int x = (int) (Math.random() * (4 - 1 + 1) + 1);
                    if(x == 1)
                    {
                        p.npc[0].yeffettiva = p.settaasset.lane1;
                    }
                    if(x == 2)
                    {
                        p.npc[0].yeffettiva = p.settaasset.lane2;
                    }
                    if(x == 3)
                    {
                        p.npc[0].yeffettiva = p.settaasset.lane3;
                    }
                    if(x == 4)
                    {
                        p.npc[0].yeffettiva = p.settaasset.lane4;
                    }
                }
                if (p.npc[1].xpersa >= 1500 && b == false && ultimo!=1) {
                    b = true;
                    ultimo = 1;
                    p.npc[1].worldx = p.giocatore.screenX + 700;
                    p.npc[1].xpersa = 0;
                    int x = (int) (Math.random() * (4 - 1 + 1) + 1);
                    if(x == 1)
                    {
                        p.npc[1].yeffettiva = p.settaasset.lane1;
                    }
                    if(x == 2)
                    {
                        p.npc[1].yeffettiva = p.settaasset.lane2;
                    }
                    if(x == 3)
                    {
                        p.npc[1].yeffettiva = p.settaasset.lane3;
                    }
                    if(x == 4)
                    {
                        p.npc[1].yeffettiva = p.settaasset.lane4;
                    }
                }
                if (p.npc[2].xpersa >= 1500 && b == false && ultimo!=2) {
                    b = true;
                    ultimo = 2;
                    p.npc[2].worldx = p.giocatore.screenX + 700;
                    p.npc[2].xpersa = 0;
                    int x = (int) (Math.random() * (4 - 1 + 1) + 1);
                    if(x == 1)
                    {
                        p.npc[2].yeffettiva = p.settaasset.lane1;
                    }
                    if(x == 2)
                    {
                        p.npc[2].yeffettiva = p.settaasset.lane2;
                    }
                    if(x == 3)
                    {
                        p.npc[2].yeffettiva = p.settaasset.lane3;
                    }
                    if(x == 4)
                    {
                        p.npc[2].yeffettiva = p.settaasset.lane4;
                    }
                }
            }
            if (b == true) {
                b = false;
                try {
                    sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ThreadAvversari.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } while (0 == 0);
    }

}
