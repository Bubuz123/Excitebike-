/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excitebike;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.text.DecimalFormat;

/**
 *
 * @author Newer
 */
public class UI {

    Pannello p;
    Graphics2D g2;
    Font arial_piccolo, arial_grande;
    public boolean messaggioattivo = false;
    public String messaggio = "";
    int contmess = 0;
    public boolean giocoFinito;
    public int numcomando = 0;
    public int statotitolo = 0; //0 = menu, 1 = tutorial

    double tempo;
    DecimalFormat format = new DecimalFormat("#0.00");

    public UI(Pannello p) {
        this.p = p;

        arial_piccolo = new Font("Arial", Font.PLAIN, 40);
        arial_grande = new Font("Arial", Font.PLAIN, 80);
    }

    public void mostaMessaggio(String testo) {
        messaggio = testo;
        messaggioattivo = true;
    }

    public void draw(Graphics2D g2) {
        this.g2 = g2;

        g2.setFont(arial_piccolo);
        g2.setColor(Color.white);

        if (p.gamestate == p.statotitolo) {
            disegnatitolo();
        }
        if (p.gamestate == p.statogioca) {
            schermogioco();
        }
        if (p.gamestate == p.statopausa) {
            schermopausa();
        }
        if (p.gamestate == p.statofine) {
            schermofine();
        }
    }

    public void schermopausa() {
        //g2.setFont(g2.setFont().deriveFont(Font.PLAIN, 80F));
        String testo = "Pausa";

        //centro dello schermo
        int x = xcentro(testo), y = p.altezzaschermo / 2;

        g2.drawString(testo, x, y);
    }

    public int xcentro(String testo) {
        int lunghezza = (int) g2.getFontMetrics().getStringBounds(testo, g2).getWidth();
        return p.larghezzaschermo / 2 - lunghezza / 2;
    }

    private void disegnatitolo() {

        if (statotitolo == 0) {
            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 96F));
            String testo = "Excitebike";
            int x = xcentro(testo), y = p.Tilesfinali * 3;

            //Ombra testo
            g2.setColor(Color.gray);
            g2.drawString(testo, x + 5, y + 5);

            //Testo
            g2.setColor(Color.white);
            g2.drawString(testo, x, y);

            //Corridore
            x = p.larghezzaschermo / 2 - (p.Tilesfinali * 2) / 2;
            y += p.Tilesfinali;
            g2.drawImage(p.giocatore.destra1, x, y, p.Tilesfinali * 2, p.Tilesfinali * 2, null);

            //Menu
            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 48F));

            testo = "Gioca";
            x = xcentro(testo);
            y += p.Tilesfinali * 3;
            g2.drawString(testo, x, y);
            if (numcomando == 0) {
                g2.drawString(">", x - p.Tilesfinali, y);
            }

            testo = "Tutorial";
            x = xcentro(testo);
            y += p.Tilesfinali + 24;
            g2.drawString(testo, x, y);
            if (numcomando == 1) {
                g2.drawString(">", x - p.Tilesfinali, y);
            }

            testo = "Record";
            x = xcentro(testo);
            y += p.Tilesfinali + 24;
            g2.drawString(testo, x, y);
            if (numcomando == 2) {
                g2.drawString(">", x - p.Tilesfinali, y);
            }

            testo = "Esci";
            x = xcentro(testo);
            y += p.Tilesfinali + 24;
            g2.drawString(testo, x, y);
            if (numcomando == 3) {
                g2.drawString(">", x - p.Tilesfinali, y);
            }
        }
        else if(statotitolo == 1)
        {
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 30F));
            g2.setColor(Color.white);
            
            String testo = "Usa W per andare in alto e S per andare in basso.";
            int x = xcentro(testo);
            int y = p.Tilesfinali*2 + (p.Tilesfinali/2);
            g2.drawString(testo, x, y);
            
            testo = "Usa A per impennare e D per abbassarti. (da impennato";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            
            testo = "vai più veloce, ma se impenni troppo cadrai!)";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            
            testo = "P per accellerare e O per decellerare.";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            
            testo = "Attento agli ostacoli e agli avversari! ti faranno";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            
            testo = "cadere! Le pozze di fango ti rallenteranno. Durante";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            
            testo = "i salti ricorda di rallentare. Ci sono 3 giri.";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            
            testo = "cerca di ottenere il tempo migliore!";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 25F));
            testo = "Premi spazio per continuare";
            x = xcentro(testo);
            y += p.Tilesfinali*2;
            g2.drawString(testo, x, y);
        }
        else if(statotitolo == 2)
        {
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 42F));
            g2.setColor(Color.white);
            
            String testo = "Test";
            int x = xcentro(testo);
            int y = p.Tilesfinali*3;
            g2.drawString(testo, x, y);
            
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 25F));
            testo = "Premi spazio per continuare";
            x = xcentro(testo);
            y += p.Tilesfinali*8;
            g2.drawString(testo, x, y);
        }
        else if(statotitolo == 3)
        {
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 30F));
            g2.setColor(Color.white);
            
            String testo = "Scegli mappa:";
            int x = xcentro(testo);
            int y = p.Tilesfinali*3;
            g2.drawString(testo, x, y);
            
            testo = "1";
            x = xcentro(testo);
            y += p.Tilesfinali*2;
            g2.drawString(testo, x, y);
            if (numcomando == 0) {
                g2.drawString(">", x - p.Tilesfinali, y);
            }
            
            testo = "2";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            if (numcomando == 1) {
                g2.drawString(">", x - p.Tilesfinali, y);
            }
            
            testo = "3";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            if (numcomando == 2) {
                g2.drawString(">", x - p.Tilesfinali, y);
            }
            
            testo = "Indietro";
            x = xcentro(testo);
            y += p.Tilesfinali;
            g2.drawString(testo, x, y);
            if (numcomando == 3) {
                g2.drawString(">", x - p.Tilesfinali, y);
            }
            
            testo = "Premi D per continuare";
            x = xcentro(testo);
            y += p.Tilesfinali*3;
            g2.drawString(testo, x, y);
        }
    }

    private void schermofine() {
        g2.setColor(Color.black);
        g2.fillRect(0, 0, p.larghezzaschermo, p.altezzaschermo);
        
        g2.setColor(Color.white);
        String testo = "Fine!";
        int x = xcentro(testo);
        int y = p.Tilesfinali * 2;
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 48F));
        g2.drawString(testo, x, y);
        
        int timer = (int)p.giocatore.timer/60; //Metti il timer
        testo = "Tempo = " + timer + " secondi";
        x = xcentro(testo);
        y += p.Tilesfinali * 2;
        g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 30F));
        g2.drawString(testo, x, y);
        
        testo = "Premi spazio per continuare";
        x = xcentro(testo);
        y += p.Tilesfinali * 5;
        g2.drawString(testo, x, y);
        
    }

    private void schermogioco() {
        int timer = (int) p.giocatore.timer/60;
        g2.setColor(Color.black);
        String testo = Integer.toString(timer);
        int x = p.Tilesfinali;
        int y = p.Tilesfinali;
        g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 24F));
        g2.drawString(testo, x, y);
    }
}
