/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import excitebike.Pannello;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Newer
 */
public class Avversario extends Entity {

    public Avversario(Pannello p) {
        super(p);
        setDefault();
        /*int x = (int) (Math.random() * (3 - 1 + 1) + 1);
        if (x == 1) {
            colore = "Blu";
        } else if (x == 1) {
            colore = "Verde";
        } else {
            colore = "Viola";
        }*/
        getImage();
    }

    public void setDefault() {
        worldx = pannello.Tilesfinali * 13; //x iniziale (sul map01.txt)
        //worldy = pannello.Tilesfinali * 8; //y iniziale
        //yeffettiva = 170 + pannello.Tilesfinali; //170 lane 1, 
        direction = "Destra";
        speed = -2;
    }
    
    public void setAction()
    {
        if(contAction != 0)
        {
            contAction++;
            if(contAction >= 150)
            {
                contAction = 0;
            }
        }
        int x = (int) (Math.random() * (30 - 1 + 1) + 1);
        if(x <= 20 && contAction > 15)
        {
            direction = "Destra";
        }
        if(x > 20 && x <= 25 && contAction == 0)
        {
            contAction++;
            direction = "Su";
        }
        if(x > 25 && contAction == 0)
        {
            contAction++;
            direction = "Giu";
        }
    }

    public void getImage() {
        try {
            if (colore == "Blu") {
                su1 = ImageIO.read(getClass().getResourceAsStream("/avversari/blusu.png"));
                giu1 = ImageIO.read(getClass().getResourceAsStream("/avversari/blugiu.png"));
                destra1 = ImageIO.read(getClass().getResourceAsStream("/avversari/blu1.png"));
                destra2 = ImageIO.read(getClass().getResourceAsStream("/avversari/blu2.png"));
            } else if (colore == "Verde") {
                su1 = ImageIO.read(getClass().getResourceAsStream("/avversari/verdesu.png"));
                giu1 = ImageIO.read(getClass().getResourceAsStream("/avversari/verdegiu.png"));
                destra1 = ImageIO.read(getClass().getResourceAsStream("/avversari/verde1.png"));
                destra2 = ImageIO.read(getClass().getResourceAsStream("/avversari/verde2.png"));
            } else {
                su1 = ImageIO.read(getClass().getResourceAsStream("/avversari/violasu.png"));
                giu1 = ImageIO.read(getClass().getResourceAsStream("/avversari/violagiu.png"));
                destra1 = ImageIO.read(getClass().getResourceAsStream("/avversari/viola1.png"));
                destra2 = ImageIO.read(getClass().getResourceAsStream("/avversari/viola2.png"));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
