/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package background;

import excitebike.Pannello;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.Buffer;
import javax.imageio.ImageIO;
/**
 *
 * @author Acer
 */
public class BackManager {
    Pannello p;
    Background[] background;
    int grandezzamappa[][];
    
    public BackManager (Pannello p)
    {
        this.p=p;
        background = new Background[10];
        grandezzamappa = new int[p.colonneschermo][p.righeschermo];
        getBackImage();
        creamappa("/maps/map01.txt");
    }
    public void getBackImage()
    {
        try{
            background[0] = new Background();
            background[0].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/road.png"));
            
            background[1] = new Background();
            background[1].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/wall.png"));
            
        }catch(IOException e){
        e.printStackTrace();
    }
    }
    public void creamappa(String filePath)
    {
        try{
            InputStream is=getClass().getResourceAsStream(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            int col=0;
            int row=0;
            while(col <p.colonneschermo && row<p.righeschermo){
                String line= br.readLine();
                while(col <p.colonneschermo){
                    String numbers[]=line.split(" ");
                    
                    int num=Integer.parseInt(numbers[col]);
                    
                    grandezzamappa[col][row]=num;
                    col++;
                }
                if(col == p.colonneschermo){
                    col = 0;
                    row++;
                }
                
            }
            br.close();
        }catch(Exception e)
        {
            
        }
    }
    public void disegna(Graphics2D g2){
        //g2.drawImage(background[0].image, 0, 0, p.Tilesfinali, p.Tilesfinali, null);
        //g2.drawImage(background[1].image, 48, 0, p.Tilesfinali, p.Tilesfinali, null);
        
        
        //automatizzare il tutto
       
        int col = 0;
        int row=0; 
        int x = 0;
        int y = 0;
        while(col <p.colonneschermo && row<p.righeschermo )
        {
             int numap = grandezzamappa[col][row];
            g2.drawImage(background[numap].image, x, y, p.Tilesfinali, p.Tilesfinali, null);
            col++;
            x+=p.Tilesfinali;
            if(col == p.colonneschermo){
                col=0;
                x=0;
                row++;
                y+=p.Tilesfinali;
            }
        }
    }

    
}
