/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excitebike;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author apuzzo_cristian
 */
public class Controlli implements KeyListener{

    public boolean supremuto, giupremuto, destrapremuto, sinistrapremuto;
    
    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if(code == KeyEvent.VK_W)
        {
            supremuto = true;
        }
        if(code == KeyEvent.VK_S)
        {
            giupremuto = true;
        }
        if(code == KeyEvent.VK_A)
        {
            destrapremuto = true;
        }
        if(code == KeyEvent.VK_D)
        {
            sinistrapremuto = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if(code == KeyEvent.VK_W)
        {
            supremuto = false;
        }
        if(code == KeyEvent.VK_S)
        {
            giupremuto = false;
        }
        if(code == KeyEvent.VK_A)
        {
            destrapremuto = false;
        }
        if(code == KeyEvent.VK_D)
        {
            sinistrapremuto = false;
        }
    }
    
}
