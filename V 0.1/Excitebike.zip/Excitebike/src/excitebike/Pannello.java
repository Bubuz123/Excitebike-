/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excitebike;

import entity.Player;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

/**
 *
 * @author apuzzo_cristian
 */
public class Pannello extends JPanel implements Runnable {

    final int Tilesoriginali = 16; //larghezza tiles 16x16
    final int ingrandimento = 3;
    public final int Tilesfinali = 16 * 3; //usa questi tiles
    final int colonneschermo = 16;
    final int righeschermo = 12;
    final int larghezzaschermo = Tilesfinali * colonneschermo;
    final int altezzaschermo = Tilesfinali * righeschermo;
    int FPS = 60;

    Controlli controlli = new Controlli();
    Thread threadgioco;
    Player giocatore = new Player(this, controlli);

    //posizioni moto
    //solo per testing
    int motox = 100;
    int motoy = 100;
    int velmoto = 4;

    public Pannello() {
        this.setPreferredSize(new Dimension(larghezzaschermo, altezzaschermo));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(controlli);
        this.setFocusable(true);
    }

    public void Inizio() {
        threadgioco = new Thread(this);
        threadgioco.start();
    }

    /*@Override
    public void run() {
        double intervallo = 1000000000/FPS;
        double prossimointervallo = System.nanoTime() + intervallo;
        while (threadgioco != null)
        {
            
            aggiornaschermo();
            
            repaint();
            
            try {
                double temporimanente = prossimointervallo - System.nanoTime();
                temporimanente = temporimanente/1000000;
                
                if(temporimanente < 0)
                {
                    temporimanente = 0;
                }
                Thread.sleep((long) temporimanente);
                
                prossimointervallo += intervallo;
            } catch (InterruptedException ex) {
                Logger.getLogger(Pannello.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }*/

    @Override
    public void run() {
        double intervallo = 1000000000 / FPS; //intervallo in millisec di 60fps
        double delta = 0;
        long ultimoTempo = System.nanoTime();
        long Tempocorrente;
        long timer = 0; 
        int cont = 0;
        while (threadgioco != null) {
            Tempocorrente = System.nanoTime();
            delta += (Tempocorrente - ultimoTempo) / intervallo;
            timer += (Tempocorrente - ultimoTempo);
            ultimoTempo = Tempocorrente;
            if (delta >= 1) {
                aggiornaschermo();

                repaint();
                delta--;
                cont++;
            }
            if(timer >= 1000000000)
            {
                System.out.println("FPS = " + cont);
                cont = 0;
                timer = 0;
            }
        }
    }

    public void aggiornaschermo() {
        //controlli tasti premuti
        giocatore.aggiorna();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        
        giocatore.draw(g2);
        g2.dispose();
    }
}
