/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package background;

import excitebike.Pannello;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.Buffer;
import javax.imageio.ImageIO;
/**
 *
 * @author Acer
 */
public class BackManager {
    Pannello p;
    public Background[] background;
    public int grandezzamappa[][];
    public String nummappa;
    
    public BackManager (Pannello p, String nummappa)
    {
        this.p=p;
        this.nummappa = nummappa;
        background = new Background[10];
        grandezzamappa = new int[p.maxWorldCol][p.maxWorldRig];
        getBackImage();
        creamappa(nummappa);
        //creamappa("/maps/map01.txt");
    }
    public void getBackImage()
    {
        try{
            //qua i tiles della mappa
            background[0] = new Background();
            background[0].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Road.png"));
            
            background[1] = new Background();
            background[1].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Wall.png"));
            background[1].collision = true;
            background[1].collisiontype = "Normale";
            
            background[2] = new Background();
            background[2].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Spalto.png"));
            background[2].collision = true;
            background[2].collisiontype = "Normale";
            
            background[3] = new Background();
            background[3].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Bordo.png"));
            background[3].collision = true;
            background[3].collisiontype = "Normale";
            
            background[4] = new Background();
            background[4].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Erba.png"));
            background[4].collision = true;
            background[4].collisiontype = "Normale";
            
            background[5] = new Background();
            background[5].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Linea.png"));
            
            background[6] = new Background();
            background[6].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Chiazza.png"));
            background[6].collision = true;
            background[6].collisiontype = "Rallenta"; 
            
            background[7] = new Background();
            background[7].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Ostacolo.png"));
            background[7].collision = true;
            background[7].collisiontype = "Ostacolo"; 
            
            background[8] = new Background();
            background[8].image = ImageIO.read(getClass().getResourceAsStream("/Sfondo/Salto.png"));
            background[8].collision = true;
            background[8].collisiontype = "Rallenta"; //cambialo
        }catch(IOException e){
        e.printStackTrace();
    }
    }
    public void creamappa(String filePath)
    {
        try{
            InputStream is=getClass().getResourceAsStream(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            int col=0;
            int row=0;
            while(col <p.maxWorldCol && row<p.maxWorldRig){
                String line= br.readLine();
                while(col <p.maxWorldCol){
                    String numbers[]=line.split(" ");
                    
                    int num=Integer.parseInt(numbers[col]);
                    
                    grandezzamappa[col][row]=num;
                    col++;
                }
                if(col == p.maxWorldCol){
                    col = 0;
                    row++;
                }
                
            }
            br.close();
        }catch(Exception e)
        {
            
        }
    }
    public void disegna(Graphics2D g2){
        //g2.drawImage(background[0].image, 0, 0, p.Tilesfinali, p.Tilesfinali, null);
        //g2.drawImage(background[1].image, 48, 0, p.Tilesfinali, p.Tilesfinali, null);
       
        int col = 0;
        int row=0; 
        
        while(col <p.maxWorldCol && row<p.maxWorldRig )
        {
            int numap = grandezzamappa[col][row];
            
            int worldx = col * p.Tilesfinali;
            int worldy = row * p.Tilesfinali;
            int screenx = worldx - p.giocatore.worldx + p.giocatore.screenX;
            int screeny = worldy - 380 + p.giocatore.screenY; //compensazione manuale 380
            
            //disegna solo i tiles che si vedono per non rallentare (+ 1 o 2 tiles per non vedere parti nere)
            if(worldx + (p.Tilesfinali*3) > p.giocatore.worldx - p.giocatore.screenX &&
               worldx - (p.Tilesfinali*3) < p.giocatore.worldx + p.giocatore.screenX &&
               worldy + (p.Tilesfinali*3) > p.giocatore.worldy - p.giocatore.screenY &&
               worldy - (p.Tilesfinali*3) < p.giocatore.worldy + p.giocatore.screenY)
            {
                g2.drawImage(background[numap].image, screenx, screeny, p.Tilesfinali, p.Tilesfinali, null);
            }
            col++;
            if(col == p.maxWorldCol){
                col=0;
                row++;
            }
        }
    }

    
}
