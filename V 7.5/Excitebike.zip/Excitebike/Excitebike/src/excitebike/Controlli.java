/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excitebike;

import background.BackManager;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author apuzzo_cristian
 */
public class Controlli implements KeyListener {

    Pannello p;
    BackManager bm;

    public boolean supremuto, giupremuto, destrapremuto, sinistrapremuto, accellerapremuto, decellerapremuto;

    public Controlli(Pannello p) {
        this.p = p;
        this.bm = bm;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();

        if (p.gamestate == p.statotitolo) {

            if (p.ui.statotitolo == 0) {
                if (code == KeyEvent.VK_W) {
                    if (p.ui.numcomando != 0) {
                        p.ui.numcomando--;
                    }
                }
                if (code == KeyEvent.VK_S) {
                    if (p.ui.numcomando != 3) {
                        p.ui.numcomando++;
                    }
                }
                if (code == KeyEvent.VK_ENTER) {
                    if (p.ui.numcomando == 0) {
                        p.ui.statotitolo = 3;
                        p.ui.numcomando = 0;
                    }
                    else if (p.ui.numcomando == 1) {
                        //Tutorial
                        p.ui.statotitolo = 1;
                    }
                    else if (p.ui.numcomando == 2) {
                        //Record
                        p.ui.statotitolo = 2;
                    }
                    else if (p.ui.numcomando == 3) {
                        System.exit(0);
                    }
                }
            }
            if (p.ui.statotitolo == 1) {
                if(code == KeyEvent.VK_SPACE)
                {
                    p.ui.statotitolo = 0;
                }
            }
            if (p.ui.statotitolo == 2) {
                if(code == KeyEvent.VK_SPACE)
                {
                    p.ui.statotitolo = 0;
                }
            }
            if (p.ui.statotitolo == 3) {
                if (code == KeyEvent.VK_W) {
                    if (p.ui.numcomando != 0) {
                        p.ui.numcomando--;
                    }
                }
                if (code == KeyEvent.VK_S) {
                    if (p.ui.numcomando != 3) {
                        p.ui.numcomando++;
                    }
                }
                if(code == KeyEvent.VK_D)
                {
                    if (p.ui.numcomando == 0) {
                        bm = new BackManager(p, "/maps/map01.txt");
                        p.backM = bm;
                        p.gamestate = p.statogioca;
                        //Musica gioco
                    }
                    if (p.ui.numcomando == 1) {
                        bm = new BackManager(p, "/maps/map02.txt");
                        p.backM = bm;
                        p.gamestate = p.statogioca;
                        //Musica gioco
                    }
                    if (p.ui.numcomando == 2) {
                        bm = new BackManager(p, "/maps/map03.txt");
                        p.backM = bm;
                        p.gamestate = p.statogioca;
                        //Musica gioco
                    }
                    if (p.ui.numcomando == 3)
                    {
                        p.ui.numcomando = 0;
                        p.ui.statotitolo = 0;
                    }
                }
            }
        }

        if (p.gamestate == p.statogioca || p.gamestate == p.statopausa) {
            if (code == KeyEvent.VK_W) {
                supremuto = true;
            }
            if (code == KeyEvent.VK_S) {
                giupremuto = true;
            }
            if (code == KeyEvent.VK_A) {
                sinistrapremuto = true;
            }
            if (code == KeyEvent.VK_D) {
                destrapremuto = true;
            }
            if (code == KeyEvent.VK_P) {
                accellerapremuto = true;
            }
            if (code == KeyEvent.VK_O) {
                decellerapremuto = true;
            }
            if (code == KeyEvent.VK_SPACE) {
                if (p.gamestate == p.statogioca) {
                    p.gamestate = p.statopausa;
                } else if (p.gamestate == p.statopausa) {
                    p.gamestate = p.statogioca;
                }
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_W) {
            supremuto = false;
        }
        if (code == KeyEvent.VK_S) {
            giupremuto = false;
        }
        if (code == KeyEvent.VK_A) {
            sinistrapremuto = false;
        }
        if (code == KeyEvent.VK_D) {
            destrapremuto = false;
        }
        if (code == KeyEvent.VK_P) {
            accellerapremuto = false;
        }
        if (code == KeyEvent.VK_O) {
            decellerapremuto = false;
        }
    }

}
