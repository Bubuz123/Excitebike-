/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excitebike;

import entity.Avversario;

/**
 *
 * @author Newer
 */
public class Settaasset {
    
    Pannello p;
    public int lane1, lane2, lane3, lane4;

    public Settaasset(Pannello p) {
        this.p = p;
        lane1 = 170;
        lane2 = 170 + p.Tilesfinali;
        lane3 = 170 + p.Tilesfinali*2;
        lane4 = 170 + p.Tilesfinali*3;
    }
    
    public void setNPC()
    {
        p.npc[0] = new Avversario(p);
        p.npc[0].worldx = p.Tilesfinali * 29;
        p.npc[0].colore = "Blu";
        p.npc[0].getImage();
        
        p.npc[1] = new Avversario(p);
        p.npc[1].worldx = p.Tilesfinali * 25;
        p.npc[1].colore = "Verde";
        p.npc[1].getImage();
        
        p.npc[2] = new Avversario(p);
        p.npc[2].worldx = p.Tilesfinali * 17;
        p.npc[2].colore = "Viola";
        p.npc[2].getImage();
        
        int x = (int) (Math.random() * (4 - 1 + 1) + 1);
        if(x==1)
        {
            p.npc[0].yeffettiva = lane1;
            p.npc[1].yeffettiva = lane3;
            p.npc[2].yeffettiva = lane4;
        }
        if(x==2)
        {
            p.npc[0].yeffettiva = lane2;
            p.npc[1].yeffettiva = lane3;
            p.npc[2].yeffettiva = lane1;
        }
        if(x==3)
        {
            p.npc[0].yeffettiva = lane2;
            p.npc[1].yeffettiva = lane3;
            p.npc[2].yeffettiva = lane4;
        }
        if(x==4)
        {
            p.npc[0].yeffettiva = lane1;
            p.npc[1].yeffettiva = lane2;
            p.npc[2].yeffettiva = lane4;
        }
    }
}
