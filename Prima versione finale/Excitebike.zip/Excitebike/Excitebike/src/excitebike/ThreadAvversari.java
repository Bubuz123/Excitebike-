/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excitebike;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Newer
 */
public class ThreadAvversari extends Thread {

    Pannello p;
    int ultimo = 4; //Salva l'ultimo avversario teletrasportato (4 = vuoto)

    public ThreadAvversari(Pannello p) {
        this.p = p;
    }

    @Override
    public void run() {
        do {
            System.out.print(""); //Serve per farlo rimanere dentro
            if (p.gamestate == p.statogioca) {
                if (p.npc[0].xpersa >= 1500 && ultimo != 0) {
                    ultimo = 0;
                    Randomlane();
                }
                if (p.npc[1].xpersa >= 1500 && ultimo != 1) {
                    ultimo = 1;
                    Randomlane();
                }
                if (p.npc[2].xpersa >= 1500 && ultimo != 2) {
                    ultimo = 2;
                    Randomlane();
                }
            }
        } while (true);

    }

    public synchronized void Randomlane() {
        p.npc[ultimo].worldx = p.giocatore.screenX + 700;
        p.npc[ultimo].xpersa = 0;
        int x = (int) (Math.random() * (4 - 1 + 1) + 1);
        if (x == 1) {
            p.npc[ultimo].yeffettiva = p.settaasset.lane1;
        }
        if (x == 2) {
            p.npc[ultimo].yeffettiva = p.settaasset.lane2;
        }
        if (x == 3) {
            p.npc[ultimo].yeffettiva = p.settaasset.lane3;
        }
        if (x == 4) {
            p.npc[ultimo].yeffettiva = p.settaasset.lane4;
        }
        try {
            sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(ThreadAvversari.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
