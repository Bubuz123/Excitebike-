/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excitebike;

import background.BackManager;
import entity.Entity;
import entity.Player;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author apuzzo_cristian
 */
public class Pannello extends JPanel implements Runnable {

    final int Tilesoriginali = 16; //larghezza tiles 16x16
    final int ingrandimento = 3;
    public final int Tilesfinali = 16 * 3; //usa questi tiles - tileSize
    public final int colonneschermo = 16;
    public final int righeschermo = 12;
    public final int larghezzaschermo = Tilesfinali * colonneschermo;
    public final int altezzaschermo = Tilesfinali * righeschermo;
    int FPS = 60;

    public final int maxWorldCol = 270;
    public final int maxWorldRig = 17;
    public final int larghezzaMondo = Tilesfinali * maxWorldCol;
    public final int altezzaMondo = Tilesfinali * maxWorldRig;

    BackManager backM;
    Controlli controlli = new Controlli(this);
    public UI ui = new UI(this);
    suono suoni = new suono();

    public Collisioni collisioni = new Collisioni(this);

    public Player giocatore = new Player(this, controlli);
    public Settaasset settaasset = new Settaasset(this);
    public Entity npc[] = new Entity[10];
    ThreadAvversari tav = new ThreadAvversari(this);

    Thread threadgioco;

    public int gamestate;
    public final int statogioca = 1;
    public final int statopausa = 2;
    public final int statotitolo = 3;
    public final int statofine = 4;

    public Pannello() {
        this.setPreferredSize(new Dimension(larghezzaschermo, altezzaschermo));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(controlli);
        this.setFocusable(true);
    }

    public void Inizio() {
        threadgioco = new Thread(this);
        threadgioco.start();
        settaasset.setNPC();
        tav.start();
        gamestate = statotitolo;
        //suona(0);
    }

    @Override
    public void run() {
        double intervallo = 1000000000 / FPS; //intervallo in millisec di 60fps
        double delta = 0;
        long ultimoTempo = System.nanoTime();
        long Tempocorrente;
        long timer = 0;
        int cont = 0;
        while (threadgioco != null) {
            Tempocorrente = System.nanoTime();
            delta += (Tempocorrente - ultimoTempo) / intervallo;
            timer += (Tempocorrente - ultimoTempo);
            ultimoTempo = Tempocorrente;
            if (delta >= 1) {
                aggiornaschermo();
                repaint();
                delta--;
                cont++;
            }
            if (timer >= 1000000000) {
                System.out.println("FPS = " + cont);
                cont = 0;
                timer = 0;
            }
        }
    }

    public void aggiornaschermo() {
        if (gamestate == statogioca) {
            giocatore.aggiorna();
            npc[0].update();
            npc[1].update();
            npc[2].update();
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        //Titolo
        if (gamestate == statotitolo) {
            ui.draw(g2);
        } else { //Resto
            if (backM != null) {
                backM.disegna(g2);
            }
            giocatore.draw(g2);

            for(int i = 0; i < npc.length; i++)
            {
                if(npc[i] != null)
                {
                    npc[i].draw(g2);
                }
            }
            ui.draw(g2);
            g2.dispose();
        }
    }
    /*public void suona(int i)
    {
        suoni.setFile(i);
        suoni.play();
        suoni.loop();
    }
    public void fermamusica()
    {
        suoni.stop();
    }
    public void suonaES(int i)
    {
        suoni.setFile(i);
        suoni.play();
            
    }*/

}
