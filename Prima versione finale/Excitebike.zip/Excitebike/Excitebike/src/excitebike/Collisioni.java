/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excitebike;

import entity.Entity;
import java.awt.Rectangle;

/**
 *
 * @author Newer
 */
public class Collisioni {

    Pannello p;

    public Collisioni(Pannello p) {
        this.p = p;
    }

    public void controllaTile(Entity e) {
        int vel = (int) e.speed;
        
        int esinistraworldx = e.worldx + e.hitbox.x;
        int edestraworldx = e.worldx + e.hitbox.x + e.hitbox.width;
        int esuworldy = e.worldy + e.hitbox.y;
        int egiuworldy = e.worldy + e.hitbox.y + e.hitbox.height;

        int esinistracol = esinistraworldx / p.Tilesfinali;
        int edestracol = edestraworldx / p.Tilesfinali;
        int esurig = esuworldy / p.Tilesfinali;
        int egiurig = egiuworldy / p.Tilesfinali;

        int numtile1, numtile2;

        switch (e.direction) {
            case "su":
                esurig = (esuworldy - p.Tilesfinali / 2) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][esurig];
                numtile2 = p.backM.grandezzamappa[edestracol][esurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Salto" || p.backM.background[numtile2].collisiontype == "Salto") {
                        e.collisiontype = "Salto";
                    }
                }
                break;
            case "giu":
                egiurig = (egiuworldy + p.Tilesfinali / 2) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][egiurig];
                numtile2 = p.backM.grandezzamappa[edestracol][egiurig];
                e.collision = true;
                if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                    e.collisiontype = "Rallenta";
                }
                if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                    e.collisiontype = "Ostacolo";
                }
                if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                    e.collisiontype = "Normale";
                }
                if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                    e.collisiontype = "Fine";
                }
                if (p.backM.background[numtile1].collisiontype == "Salto" || p.backM.background[numtile2].collisiontype == "Salto") {
                        e.collisiontype = "Salto";
                }
                break;
            case "sinistra":
                esinistracol = (esinistraworldx - vel) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][esurig];
                numtile2 = p.backM.grandezzamappa[esinistracol][egiurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Salto" || p.backM.background[numtile2].collisiontype == "Salto") {
                        e.collisiontype = "Salto";
                    }
                }
                break;
            case "destra":
                edestracol = (edestraworldx + vel) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[edestracol][esurig];
                numtile2 = p.backM.grandezzamappa[edestracol][egiurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Salto" || p.backM.background[numtile2].collisiontype == "Salto") {
                        e.collisiontype = "Salto";
                    }
                }
                break;
        }
    }

    /*public int CheckEntity(Entity e, Entity[] e2) {
        int index = 999;
        Rectangle hitboxe = e.hitbox;
        Rectangle hitboxe2;

        for (int i = 0; i < e2.length; i++) {
            hitboxe2 = e2[i].hitbox;
            if (e2[i] != null) {
                hitboxe.x = e.worldx + hitboxe.x;
                hitboxe.y = e.worldy + hitboxe.y;

                hitboxe2.x = e2[i].worldx + hitboxe2.x;
                hitboxe2.y = e2[i].worldy + hitboxe2.y;

                switch (e.direction) {
                    case "Su":
                        hitboxe.y -= e.speed;
                        if (hitboxe.intersects(hitboxe2)) {
                            e.collision = true;
                            e.collisiontype = "Normale";
                            index = 1;
                        }
                        break;
                    case "Giu":
                        hitboxe.y += e.speed;
                        if (hitboxe.intersects(hitboxe2)) {
                            e.collision = true;
                            e.collisiontype = "Normale";
                            index = 1;
                        }
                        break;
                    case "Destra":
                        hitboxe.x += e.speed;
                        if (hitboxe.intersects(hitboxe2)) {
                            e.collision = true;
                            e.collisiontype = "Normale";
                            index = 1;
                        }
                        hitboxe.x -= e.speed;
                        if (hitboxe.intersects(hitboxe2)) {
                            e.collision = true;
                            e.collisiontype = "Normale";
                            index = 1;
                        }
                        break;
                }
            }
        }
        return index;
    }*/
}
