/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import excitebike.Pannello;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Newer
 */
public class Entity {

    Pannello pannello;
    
    public String colore="";

    public int worldx, worldy, xpersa=0, yeffettiva;
    public double speed;

    //Posizioni delle moto
    public BufferedImage su1, giu1, sinistra1, sinistra2, sinistra3, destra1, destra2, caduta1, caduta2, caduta3, salto1, salto2, salto3, fine; //qua metti tutti gli sprite
    public String direction;

    public int contSprite = 0; //dopo un tot switcha lo sprite con animazione
    public int numSprite = 1; //numero sprite

    public Rectangle hitbox;
    public boolean collision = false;
    public String collisiontype;
    
    public int contAction = 0;

    public Entity(Pannello p) {
        this.pannello = p;
        hitbox = new Rectangle(0, 0, pannello.Tilesfinali, 30);
    }

    public void setAction() {
        //Override nei vari NPC
    }
    
    public void getImage() {
        //Override nelle varie entity
    }

    //Update utilizzato solo dai NPC (Il player fa Override)
    public void update() {
        setAction();
        
        //Movimento npc
        if(pannello.giocatore.velcorrente < 4 && pannello.giocatore.velcorrente > 2)
        {
            worldx -= 2;
            xpersa += 2;
        } else if(pannello.giocatore.velcorrente > 4 && pannello.giocatore.velcorrente < 6)
        {
            worldx -= 4;
            xpersa += 4;
        } else if(pannello.giocatore.velcorrente > 6 && pannello.giocatore.velcorrente < 8)
        {
            worldx -= 5;
            xpersa += 5;
        }
        else if(pannello.giocatore.velcorrente < 3 && pannello.giocatore.velcorrente > 0)
        {
            worldx += 2;
            xpersa -= 2;
        } else if(pannello.giocatore.velcorrente == 0)
        {
            worldx += 4;
            xpersa -= 4;
        }
        else
        {
            worldx -= 10;
            xpersa += 10;
        }

        //Aggiorna sprite
        contSprite++;
        if (contSprite > 10)
        {
            if (numSprite == 1) {
                numSprite = 2;
            } else if (numSprite == 2) {
                numSprite = 1;
            }
            contSprite = 0;
        }
    }

    //Draw utilizzato solo dai NPC (Player Override)
    public void draw(Graphics2D g2) {
        int screenX = worldx;
        
        BufferedImage image = null;

        switch (direction) {
            case "Destra":
                if (numSprite == 1) {
                    image = destra1;
                } else {
                    image = destra2;
                }
                break;
            case "Su":
                image = su1;
                break;
            case "Giu":
                image = giu1;
                break;
        }

        g2.drawImage(image, screenX, yeffettiva, pannello.Tilesfinali, pannello.Tilesfinali, null);
    }
}
