/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file Background.java 
* 
* @brief File che contiene la classe padre di ogni tile
*
*/
package background;

import java.awt.image.BufferedImage;

/**
 *
 * @author Acer
 */

/** 
* @class Background
* 
* @brief Classe padre di ogni tile
* 
* Contiene gli attributi dei tiles
*/
public class Background {
    
    /** Immagine del tile
    * 
    * @var BufferedImage
    */
    public BufferedImage image;
    /** Variabile per vedere se i tile hanno le collisioni
    * 
    * @var boolean
    */
    public boolean collision = false;
    /** Variabile per vedere il tipo di collisione del tile
    * 
    * @var String
    */
    public String collisiontype = "";
}
