/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file Entity.java 
* 
* @brief File che contiene la classe delle Entity
*
*/
package entity;

import excitebike.Pannello;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Newer
 */
/**
 * @class Entity
 *
 * @brief Classe padre che gestisce le entità 
 *
 * Inizializza i vari attributi delle entità e gestisce i metodi delle entità che 
 * non fanno override
 */
public class Entity {

    /** Pannello di gioco 
    * 
    * @var Pannello
    */
    Pannello pannello;
    
    /** Colore dell'entità 
    * 
    * @var String
    */
    public String colore="";

    /** Posizione x e y dell'entità, distanza dal giocatore, e y effettiva dell'entità
    * 
    * @var int
    */
    public int worldx, worldy, xpersa=0, yeffettiva;
    /** Velocità massima dell'entità
    * 
    * @var double
    */
    public double speed;

    /** Varie posizioni possibili delle moto
    * 
    * @var BufferedImage
    */
    public BufferedImage su1, giu1, sinistra1, sinistra2, sinistra3, destra1, destra2, caduta1, caduta2, caduta3, salto1, salto2, salto3, fine; //qua metti tutti gli sprite
    /** Direzione dell'entità
    * 
    * @var String
    */
    public String direction;

    /** Contatore per animare l'entità
    * 
    * @var int
    */
    public int contSprite = 0; //dopo un tot switcha lo sprite con animazione
    /** Numero dell'animazione
    * 
    * @var int
    */
    public int numSprite = 1; //numero sprite

    /** Hitbox dell'entità
    * 
    * @var Rectangle
    */
    public Rectangle hitbox;
    /** Segna se il tile al disotto dell'entità ha collisioni
    * 
    * @var boolean
    */
    public boolean collision = false;
    /** Segna il tipo di collisione che ha il tile al disotto dell'entità
    * 
    * @var String
    */
    public String collisiontype;
    
    /** Numero dell'azione per le entità non player
    * 
    * @var int
    */
    public int contAction = 0;

    /**
     * @brief Costruttore della classe
     *
     * Inizializza la hitbox e setta il pannello di gioco
     * @param Pannello p Pannello utilizzato dal gioco
     */
    public Entity(Pannello p) {
        this.pannello = p;
        hitbox = new Rectangle(0, 0, pannello.Tilesfinali, 30);
    }

    /**
     * @brief Metodo che setta l'azione che l'entità sta eseguendo 
     *
     * Viene fatto l'override nelle varie entità che lo usano
     */
    public void setAction() {
        //Override nei vari NPC
    }
    
    /**
     * @brief Metodo che setta le immagini delle entità
     *
     * Viene fatto l'override nelle varie entità che lo usano
     */
    public void getImage() {
        //Override nelle varie entity
    }

    /**
     * @brief Metodo che aggiorna lo stato di gioco
     *
     * Aggiorna la posizione dell'entità e dello schermo (Il player esegue un override)
     */
    public void update() {
        setAction();
        
        //Movimento npc
        if(pannello.giocatore.velcorrente < 4 && pannello.giocatore.velcorrente > 2)
        {
            worldx -= 2;
            xpersa += 2;
        } else if(pannello.giocatore.velcorrente > 4 && pannello.giocatore.velcorrente < 6)
        {
            worldx -= 4;
            xpersa += 4;
        } else if(pannello.giocatore.velcorrente > 6 && pannello.giocatore.velcorrente < 8)
        {
            worldx -= 5;
            xpersa += 5;
        }
        else if(pannello.giocatore.velcorrente < 3 && pannello.giocatore.velcorrente > 0)
        {
            worldx += 2;
            xpersa -= 2;
        } else if(pannello.giocatore.velcorrente == 0)
        {
            worldx += 4;
            xpersa -= 4;
        }
        else
        {
            worldx -= 10;
            xpersa += 10;
        }

        //Aggiorna sprite
        contSprite++;
        if (contSprite > 10)
        {
            if (numSprite == 1) {
                numSprite = 2;
            } else if (numSprite == 2) {
                numSprite = 1;
            }
            contSprite = 0;
        }
    }

    /**
     * @brief Metodo che disegna l'entità
     *
     * Disegna lo sprite utilizzato dall'entità in quel momento (Il player esegue un override)
     * @param Graphics2D g2 Parametro che contiene le impostazioni grafiche del pannello di gioco
     */
    public void draw(Graphics2D g2) {
        int screenX = worldx;
        
        BufferedImage image = null;

        switch (direction) {
            case "Destra":
                if (numSprite == 1) {
                    image = destra1;
                } else {
                    image = destra2;
                }
                break;
            case "Su":
                image = su1;
                break;
            case "Giu":
                image = giu1;
                break;
        }

        g2.drawImage(image, screenX, yeffettiva, pannello.Tilesfinali, pannello.Tilesfinali, null);
        
        //Test collisione
        Rectangle r = new Rectangle(screenX, yeffettiva, pannello.Tilesfinali, 30);
        if(r.intersects(pannello.giocatore.hitbox))
        {
            pannello.giocatore.stato = "Caduta";
            pannello.giocatore.contacaduta = 1;
        }
    }
}
