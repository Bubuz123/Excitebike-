/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file Avversario.java 
* 
* @brief File che contiene la classe degli avversari
*
*/
package entity;

import excitebike.Pannello;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Newer
 */
/**
 * @class Avversario
 *
 * @brief Classe che gestisce il tipo di Entity avversari 
 *
 * Inizializza gli avversari e gestisce i loro movimenti
 */
public class Avversario extends Entity {

    /**
     * @brief Costruttore della classe
     *
     * Richiama il costruttore della classe Entity, setta la direzione e prende le immagini
     * per disegnare
     * @param Pannello p Pannello utilizzato dal gioco
     */
    public Avversario(Pannello p) {
        super(p);
        setDefault();
        getImage();
    }

    /**
     * @brief Metodo che assegna la direzione di default
     *
     * Richiamata ogni volta che si entra in partita
     */
    public void setDefault() {
        direction = "Destra";
    }
    
    /**
     * @brief Metodo che genera una mossa random da eseguire
     *
     * Genera un numero random e assegna la direzione che ne consegue
     */
    public void setAction() //Azione Random
    {
        if(contAction != 0)
        {
            contAction++;
            if(contAction >= 150)
            {
                contAction = 0;
            }
        }
        int x = (int) (Math.random() * (30 - 1 + 1) + 1);
        if(x <= 20 && contAction > 15)
        {
            direction = "Destra";
        }
        if(x > 20 && x <= 25 && contAction == 0)
        {
            contAction++;
            direction = "Su";
        }
        if(x > 25 && contAction == 0)
        {
            contAction++;
            direction = "Giu";
        }
    }

    /**
     * @brief Metodo che assegna lae immagini da disegnare per gli avversari
     *
     * Le immagini dipendono dal colore dell'entità
     */
    public void getImage() {
        try {
            if (colore == "Blu") {
                su1 = ImageIO.read(getClass().getResourceAsStream("/avversari/blusu.png"));
                giu1 = ImageIO.read(getClass().getResourceAsStream("/avversari/blugiu.png"));
                destra1 = ImageIO.read(getClass().getResourceAsStream("/avversari/blu1.png"));
                destra2 = ImageIO.read(getClass().getResourceAsStream("/avversari/blu2.png"));
            } else if (colore == "Verde") {
                su1 = ImageIO.read(getClass().getResourceAsStream("/avversari/verdesu.png"));
                giu1 = ImageIO.read(getClass().getResourceAsStream("/avversari/verdegiu.png"));
                destra1 = ImageIO.read(getClass().getResourceAsStream("/avversari/verde1.png"));
                destra2 = ImageIO.read(getClass().getResourceAsStream("/avversari/verde2.png"));
            } else {
                su1 = ImageIO.read(getClass().getResourceAsStream("/avversari/violasu.png"));
                giu1 = ImageIO.read(getClass().getResourceAsStream("/avversari/violagiu.png"));
                destra1 = ImageIO.read(getClass().getResourceAsStream("/avversari/viola1.png"));
                destra2 = ImageIO.read(getClass().getResourceAsStream("/avversari/viola2.png"));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
