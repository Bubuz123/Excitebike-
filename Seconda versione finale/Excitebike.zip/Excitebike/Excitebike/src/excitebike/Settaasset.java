/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file Settaasset.java 
* 
* @brief File che contiene la classe che setta gli asset degli avversari
*
*/
package excitebike;

import entity.Avversario;

/**
 *
 * @author Newer
 */
/**
 * @class Settaasset
 *
 * @brief Classe che setta gli asset degli avversari
 *
 * Setta i colori e le posizioni iniziali degli avversari
 */
public class Settaasset {
    
    /** Pannello di gioco 
    * 
    * @var Pannello
    */
    Pannello p;
    /** Lane del percorso
    * 
    * @var int
    */
    public int lane1, lane2, lane3, lane4;

    /**
     * @brief Costruttore della classe
     *
     * Setta il pannello di gioco e le lane
     * @param Pannello p Pannello utilizzato dal gioco
     */
    public Settaasset(Pannello p) {
        this.p = p;
        lane1 = 170;
        lane2 = 170 + p.Tilesfinali;
        lane3 = 170 + p.Tilesfinali*2;
        lane4 = 170 + p.Tilesfinali*3;
    }
    
    /**
     * @brief Metodo che setta i colori e le posizioni degli npc
     *
     * Setta i colori e la x e genera la posizione y in modo random
     */
    public void setNPC()
    {
        p.npc[0] = new Avversario(p);
        p.npc[0].worldx = p.Tilesfinali * 29;
        p.npc[0].colore = "Blu";
        p.npc[0].getImage();
        
        p.npc[1] = new Avversario(p);
        p.npc[1].worldx = p.Tilesfinali * 25;
        p.npc[1].colore = "Verde";
        p.npc[1].getImage();
        
        p.npc[2] = new Avversario(p);
        p.npc[2].worldx = p.Tilesfinali * 17;
        p.npc[2].colore = "Viola";
        p.npc[2].getImage();
        
        int x = (int) (Math.random() * (4 - 1 + 1) + 1);
        if(x==1)
        {
            p.npc[0].yeffettiva = lane1;
            p.npc[1].yeffettiva = lane3;
            p.npc[2].yeffettiva = lane4;
        }
        if(x==2)
        {
            p.npc[0].yeffettiva = lane2;
            p.npc[1].yeffettiva = lane3;
            p.npc[2].yeffettiva = lane1;
        }
        if(x==3)
        {
            p.npc[0].yeffettiva = lane2;
            p.npc[1].yeffettiva = lane3;
            p.npc[2].yeffettiva = lane4;
        }
        if(x==4)
        {
            p.npc[0].yeffettiva = lane1;
            p.npc[1].yeffettiva = lane2;
            p.npc[2].yeffettiva = lane4;
        }
    }
}
