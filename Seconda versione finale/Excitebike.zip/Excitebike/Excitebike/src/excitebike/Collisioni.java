/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file Collisioni.java 
* 
* @brief File che contiene la classe che gestisce le collisioni
*
*/
package excitebike;

import entity.Entity;

/**
 *
 * @author Newer
 */
/**
 * @class Collisioni
 *
 * @brief Classe che gestisce le collisioni con i tile
 *
 * Controlla che nei vari movimenti del giocatore il tipo di tile su cui finirà
 */
public class Collisioni {

    /** Pannello di gioco 
    * 
    * @var Pannello
    */
    Pannello p;

    /**
     * @brief Costruttore della classe
     *
     * Setta il pannello di gioco
     * @param Pannello p Pannello utilizzato dal gioco
     */
    public Collisioni(Pannello p) {
        this.p = p;
    }

    /**
     * @brief Metodo che controlla le collisioni dei tile sottostanti
     *
     * Controlla il tipo di collisione del tile dove il giocatore finirebbe
     * e aggiorna la collisiontype del giocatore
     * @param Entity e Entità a cui bisogna controllare le collisioni
     */
    public void controllaTile(Entity e) {
        int vel = (int) e.speed;
        
        int esinistraworldx = e.worldx + e.hitbox.x;
        int edestraworldx = e.worldx + e.hitbox.x + e.hitbox.width;
        int esuworldy = e.worldy + e.hitbox.y;
        int egiuworldy = e.worldy + e.hitbox.y + e.hitbox.height;

        int esinistracol = esinistraworldx / p.Tilesfinali;
        int edestracol = edestraworldx / p.Tilesfinali;
        int esurig = esuworldy / p.Tilesfinali;
        int egiurig = egiuworldy / p.Tilesfinali;

        int numtile1, numtile2;

        switch (e.direction) {
            case "su":
                esurig = (esuworldy - p.Tilesfinali / 2) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][esurig];
                numtile2 = p.backM.grandezzamappa[edestracol][esurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Salto" || p.backM.background[numtile2].collisiontype == "Salto") {
                        e.collisiontype = "Salto";
                    }
                }
                break;
            case "giu":
                egiurig = (egiuworldy + p.Tilesfinali / 2) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][egiurig];
                numtile2 = p.backM.grandezzamappa[edestracol][egiurig];
                e.collision = true;
                if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                    e.collisiontype = "Rallenta";
                }
                if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                    e.collisiontype = "Ostacolo";
                }
                if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                    e.collisiontype = "Normale";
                }
                if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                    e.collisiontype = "Fine";
                }
                if (p.backM.background[numtile1].collisiontype == "Salto" || p.backM.background[numtile2].collisiontype == "Salto") {
                        e.collisiontype = "Salto";
                }
                break;
            case "sinistra":
                esinistracol = (esinistraworldx - vel) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][esurig];
                numtile2 = p.backM.grandezzamappa[esinistracol][egiurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Salto" || p.backM.background[numtile2].collisiontype == "Salto") {
                        e.collisiontype = "Salto";
                    }
                }
                break;
            case "destra":
                edestracol = (edestraworldx + vel) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[edestracol][esurig];
                numtile2 = p.backM.grandezzamappa[edestracol][egiurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Salto" || p.backM.background[numtile2].collisiontype == "Salto") {
                        e.collisiontype = "Salto";
                    }
                }
                break;
        }
    }
}
