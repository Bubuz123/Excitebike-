/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file ThreadAvversari.java 
* 
* @brief File che contiene il thread che sposta gli avversari
*
*/
package excitebike;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Newer
 */
/**
 * @class Settaasset
 *
 * @brief Thread che sposta gli avversari
 *
 * Aggiorna la posione x degli avversari quando escono dallo schermo
 */
public class ThreadAvversari extends Thread {

    /** Pannello di gioco 
    * 
    * @var Pannello
    */
    Pannello p;
    /** Variabile che salva l'ultimo avversario spostato
    * 
    * @var int
    */
    int ultimo = 4;

    /**
     * @brief Costruttore della classe
     *
     * Setta il pannello di gioco
     * @param Pannello p Pannello utilizzato dal gioco
     */
    public ThreadAvversari(Pannello p) {
        this.p = p;
    }

    /**
     * @brief Metodo run infinito che sposta gli avversari
     *
     * Controlla se l'avversario è spostabile e chiama il metodo RandomLane
     */
    @Override
    public void run() {
        do {
            System.out.print(""); //Serve per farlo rimanere dentro
            if (p.gamestate == p.statogioca) {
                if (p.npc[0].xpersa >= 1500 && ultimo != 0) {
                    ultimo = 0;
                    Randomlane();
                }
                if (p.npc[1].xpersa >= 1500 && ultimo != 1) {
                    ultimo = 1;
                    Randomlane();
                }
                if (p.npc[2].xpersa >= 1500 && ultimo != 2) {
                    ultimo = 2;
                    Randomlane();
                }
            }
        } while (true);

    }

    /**
     * @brief Metodo sposta la x dell'avversario scelto
     *
     * Mette l'avversario a destra fuori dallo schermo e resetta la x persa
     */
    public synchronized void Randomlane() {
        p.npc[ultimo].worldx = p.giocatore.screenX + 700;
        p.npc[ultimo].xpersa = 0;
        int x = (int) (Math.random() * (4 - 1 + 1) + 1);
        if (x == 1) {
            p.npc[ultimo].yeffettiva = p.settaasset.lane1;
        }
        if (x == 2) {
            p.npc[ultimo].yeffettiva = p.settaasset.lane2;
        }
        if (x == 3) {
            p.npc[ultimo].yeffettiva = p.settaasset.lane3;
        }
        if (x == 4) {
            p.npc[ultimo].yeffettiva = p.settaasset.lane4;
        }
        try {
            sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(ThreadAvversari.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
