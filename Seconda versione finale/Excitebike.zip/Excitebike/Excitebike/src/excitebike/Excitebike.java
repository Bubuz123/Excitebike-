/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file Excitebike.java 
* 
* @brief File che contiene il main
*
*/
package excitebike;

import javax.swing.JFrame;

/**
 *
 * @author apuzzo_cristian
 */
/**
 * @class Excitebike
 *
 * @brief Classe main 
 *
 */
public class Excitebike {

    /**
     * @brief Metodo main
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setTitle("Excitebike");
        
        Pannello pannello = new Pannello();
        frame.add(pannello);
        
        frame.pack();
        
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        pannello.Inizio();
    }
    
}
