/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file suono.java 
* 
* @brief File che contiene la classe che gestisce i suoni
*
*/
package excitebike;

import java.net.URL;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 *
 * @author Acer
 */
/**
 * @class UI
 *
 * @brief Classe che gestisce i suoni
 *
 * Inizializza i vari file, caricandoli in un vettore, e da metodi per ascoltarli
 */
public class suono {
    /** Clip dell'audio
    * 
    * @var Clip
    */
    Clip clip;
    /** Vettore che contiene i percorsi degli audio
    * 
    * @var URL
    */
    URL soundURL[] = new URL[30];
    /**
     * @brief Costruttore della classe
     *
     * Inizializza i suoni e li inserisce nel vettore
     */
    public suono(){
        soundURL[1]= getClass().getResource("/Suoni/gas.wav");
    }
    /**
     * @brief Setta i percorsi del vettore
     *
     * Prende l'audio da poi riprodurre
     * @param int i Posizione dell'audio nel vettore
     */
    public void setFile(int i)
    {
        try{
            AudioInputStream ais = AudioSystem.getAudioInputStream(soundURL[i]);
            clip = AudioSystem.getClip();
            clip.open(ais);
        }catch(Exception e){
            
        }
    }
    /**
     * @brief Riproduce l'audio 
     *
     * Riproduce l'audio una volta
     */
    public void play()
    {
        clip.start();
    }
    /**
     * @brief Loopa l'audio 
     *
     * Riproduce l'audio all'infinito finchè non stoppato
     */
    public void loop()
    {
        clip.loop(Clip.LOOP_CONTINUOUSLY);
    }
    /**
     * @brief Ferma l'audio
     *
     * Ferma l'audio
     */
    public void stop()
    {
        clip.stop();
    }
}
