/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file Controlli.java 
* 
* @brief File che contiene la classe che gestisce i controlli
*
*/
package excitebike;

import background.BackManager;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author apuzzo_cristian
 */
/**
 * @class Collisioni
 *
 * @brief Classe che gestisce i controlli
 *
 * Controlla che tasto viene premuto nei vari stati di gioco e si muove
 * di conseguenza
 */
public class Controlli implements KeyListener {

    /** Pannello di gioco 
    * 
    * @var Pannello
    */
    Pannello p;
    /** Sfondo di gioco 
    * 
    * @var BackManager
    */
    BackManager bm;

    /** Variabili che salvano che tasto è premuto per vedere cosa deve fare il giocatore
    * 
    * @var boolean
    */
    public boolean supremuto, giupremuto, destrapremuto, sinistrapremuto, accellerapremuto, decellerapremuto;

    /**
     * @brief Costruttore della classe
     *
     * Setta il pannello di gioco e lo sfondo
     * @param Pannello p Pannello utilizzato dal gioco
     */
    public Controlli(Pannello p) {
        this.p = p;
        this.bm = bm;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    /**
     * @brief Metodo che controlla quale tasto viene premuto
     *
     * Dice cosa deve avvenire a seconda di che tasto viene premuto e 
     * in quale menu
     * @param KeyEvent e Evento keyevent
     */
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();

        if (p.gamestate == p.statotitolo) {

            if (p.ui.statotitolo == 0) {
                if (code == KeyEvent.VK_W) {
                    if (p.ui.numcomando != 0) {
                        p.ui.numcomando--;
                    }
                }
                if (code == KeyEvent.VK_S) {
                    if (p.ui.numcomando != 3) {
                        p.ui.numcomando++;
                    }
                }
                if (code == KeyEvent.VK_ENTER) {
                    if (p.ui.numcomando == 0) {
                        p.ui.statotitolo = 3;
                        p.ui.numcomando = 0;
                    }
                    else if (p.ui.numcomando == 1) {
                        //Tutorial
                        p.ui.statotitolo = 1;
                    }
                    else if (p.ui.numcomando == 2) {
                        //Record
                        p.ui.statotitolo = 2;
                    }
                    else if (p.ui.numcomando == 3) {
                        System.exit(0);
                    }
                }
            }
            //Comandi tutorial
            if (p.ui.statotitolo == 1) {
                if(code == KeyEvent.VK_SPACE)
                {
                    p.ui.statotitolo = 0;
                }
            }
            //Comandi record
            if (p.ui.statotitolo == 2) {
                if(code == KeyEvent.VK_SPACE)
                {
                    p.ui.statotitolo = 0;
                }
            }
            //Scelta mappa
            if (p.ui.statotitolo == 3) {
                if (code == KeyEvent.VK_W) {
                    if (p.ui.numcomando != 0) {
                        p.ui.numcomando--;
                    }
                }
                if (code == KeyEvent.VK_S) {
                    if (p.ui.numcomando != 3) {
                        p.ui.numcomando++;
                    }
                }
                if(code == KeyEvent.VK_D)
                {
                    if (p.ui.numcomando == 0) {
                        bm = new BackManager(p, "/maps/map01.txt");
                        p.backM = bm;
                        p.settaasset.setNPC();
                        p.npc[0].xpersa = 0;
                        p.npc[1].xpersa = 0;
                        p.npc[2].xpersa = 0;
                        p.gamestate = p.statogioca;
                    }
                    if (p.ui.numcomando == 1) {
                        bm = new BackManager(p, "/maps/map02.txt");
                        p.backM = bm;
                        p.settaasset.setNPC();
                        p.npc[0].xpersa = 0;
                        p.npc[1].xpersa = 0;
                        p.npc[2].xpersa = 0;
                        p.gamestate = p.statogioca;
                    }
                    if (p.ui.numcomando == 2) {
                        bm = new BackManager(p, "/maps/map03.txt");
                        p.backM = bm;
                        p.settaasset.setNPC();
                        p.npc[0].xpersa = 0;
                        p.npc[1].xpersa = 0;
                        p.npc[2].xpersa = 0;
                        p.gamestate = p.statogioca;
                    }
                    if (p.ui.numcomando == 3)
                    {
                        p.ui.numcomando = 0;
                        p.ui.statotitolo = 0;
                    }
                }
            }
        }

        //Schermata finale
        if (p.gamestate == p.statofine) {
            if (code == KeyEvent.VK_SPACE) {
                p.gamestate = p.statotitolo;
                p.giocatore.setDefault();
                p.ui.numcomando = 0;
                p.ui.statotitolo = 0;
            }
        }
        
        //Schermata di gioco e di pausa
        if (p.gamestate == p.statogioca || p.gamestate == p.statopausa) {
            if (code == KeyEvent.VK_W) {
                supremuto = true;
            }
            if (code == KeyEvent.VK_S) {
                giupremuto = true;
            }
            if (code == KeyEvent.VK_A) {
                sinistrapremuto = true;
            }
            if (code == KeyEvent.VK_D) {
                destrapremuto = true;
            }
            if (code == KeyEvent.VK_P) {
                accellerapremuto = true;
                p.suonaES(1);
            }
            if (code == KeyEvent.VK_O) {
                decellerapremuto = true;
            }
            if (code == KeyEvent.VK_SPACE) {
                if (p.gamestate == p.statogioca) {
                    p.gamestate = p.statopausa;
                } else if (p.gamestate == p.statopausa) {
                    p.gamestate = p.statogioca;
                }
            }
        }
    }

    /**
     * @brief Metodo che controlla quale tasto viene rilasciato
     *
     * Setta se l'azione che avviene quando viene premuto un tasto deve terminare
     * dopo il rilascio del tasto
     * @param KeyEvent e Evento keyevent
     */
    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_W) {
            supremuto = false;
        }
        if (code == KeyEvent.VK_S) {
            giupremuto = false;
        }
        if (code == KeyEvent.VK_A) {
            sinistrapremuto = false;
        }
        if (code == KeyEvent.VK_D) {
            destrapremuto = false;
        }
        if (code == KeyEvent.VK_P) {
            accellerapremuto = false;
        }
        if (code == KeyEvent.VK_O) {
            decellerapremuto = false;
        }
    }

}
