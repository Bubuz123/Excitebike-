/**
* @author  Apuzzo Cristian, Perrica Francesco
* @version 1.0
* @file Pannello.java 
* 
* @brief File che contiene la classe che gestisce il pannello del gioco
*
*/
package excitebike;

import background.BackManager;
import entity.Entity;
import entity.Player;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author apuzzo_cristian
 */
/**
 * @class Pannello
 *
 * @brief Classe che gestisce il pannello del gioco
 *
 * Inizializza i vari attributi dello schermo, e gestisce il gioco
 */
public class Pannello extends JPanel implements Runnable {

    /** Larghezza e altezza dei tiles
    * 
    * @var int
    */
    final int Tilesoriginali = 16;
    /** Ingrandimento dei tiles
    * 
    * @var int
    */
    final int ingrandimento = 3;
    /** Larghezza e altezza dei tiles dopo l'ingrandimento
    * 
    * @var int
    */
    public final int Tilesfinali = 16 * 3;
    /** Numero di colonne che contengono un tile nello schermo
    * 
    * @var int
    */
    public final int colonneschermo = 16;
    /** Numero di righe che contengono un tile nello schermo
    * 
    * @var int
    */
    public final int righeschermo = 12;
    /** Larghezza dello schermo di gioco
    * 
    * @var int
    */
    public final int larghezzaschermo = Tilesfinali * colonneschermo;
    /** Altezza dello schermo di gioco
    * 
    * @var int
    */
    public final int altezzaschermo = Tilesfinali * righeschermo;
    /** FPS
    * 
    * @var int
    */
    int FPS = 60;

    /** Larghezza della mappa in righe
    * 
    * @var int
    */
    public final int maxWorldCol = 270;
    /** Altezza della mappa in colonne
    * 
    * @var int
    */
    public final int maxWorldRig = 17;
    /** Larghezza della mappa
    * 
    * @var int
    */
    public final int larghezzaMondo = Tilesfinali * maxWorldCol;
    /** Altezza della mappa
    * 
    * @var int
    */
    public final int altezzaMondo = Tilesfinali * maxWorldRig;

    /** Gestione dello sfondo
    * 
    * @var BackManager
    */
    BackManager backM;
    /** Gestione dei controlli
    * 
    * @var Controlli
    */
    Controlli controlli = new Controlli(this);
    /** Gestione della UI
    * 
    * @var UI
    */
    public UI ui = new UI(this);
    /** Gestione dei suoni
    * 
    * @var suono
    */
    suono suoni = new suono();

    /** Gestione delle collisioni
    * 
    * @var Collisioni
    */
    public Collisioni collisioni = new Collisioni(this);

    /** Player
    * 
    * @var Player
    */
    public Player giocatore = new Player(this, controlli);
    /** Setter degli asset degli avversari
    * 
    * @var Settaasset
    */
    public Settaasset settaasset = new Settaasset(this);
    /** Vettore degli avversari
    * 
    * @var Entity[]
    */
    public Entity npc[] = new Entity[10];
    /** Thread che sposta gli avversari
    * 
    * @var ThreadAvversari
    */
    ThreadAvversari tav = new ThreadAvversari(this);

    /** Thread del gioco
    * 
    * @var Thread
    */
    Thread threadgioco;

    /** Stato del gioco
    * 
    * @var int
    */
    public int gamestate;
    /** Numero dello stato del gioco se in partita
    * 
    * @var int
    */
    public final int statogioca = 1;
    /** Numero dello stato del gioco se in pausa
    * 
    * @var int
    */
    public final int statopausa = 2;
    /** Numero dello stato del gioco se nel titolo
    * 
    * @var int
    */
    public final int statotitolo = 3;
    /** Numero dello stato del gioco se inei risultati
    * 
    * @var int
    */
    public final int statofine = 4;

    /**
     * @brief Costruttore della classe
     *
     * Inizializza il pannello di gioco
     */
    public Pannello() {
        this.setPreferredSize(new Dimension(larghezzaschermo, altezzaschermo));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(controlli);
        this.setFocusable(true);
    }

    /**
     * @brief Metodo che inizializza il resto del gioco
     *
     * Inizializza e fa partire i thread e le classi
     */
    public void Inizio() {
        threadgioco = new Thread(this);
        threadgioco.start();
        settaasset.setNPC();
        tav.start();
        gamestate = statotitolo;
        //suona(0);
    }

    /**
     * @brief Run del thread principale
     *
     * Fa partire il gioco
     */
    @Override
    public void run() {
        double intervallo = 1000000000 / FPS; //intervallo in millisec di 60fps
        double delta = 0;
        long ultimoTempo = System.nanoTime();
        long Tempocorrente;
        long timer = 0;
        int cont = 0;
        while (threadgioco != null) {
            Tempocorrente = System.nanoTime();
            delta += (Tempocorrente - ultimoTempo) / intervallo;
            timer += (Tempocorrente - ultimoTempo);
            ultimoTempo = Tempocorrente;
            if (delta >= 1) {
                aggiornaschermo();
                repaint();
                delta--;
                cont++;
            }
            if (timer >= 1000000000) {
                System.out.println("FPS = " + cont);
                cont = 0;
                timer = 0;
            }
        }
    }

    /**
     * @brief Aggiorna lo schermo
     *
     * Richiama i vari metodi che aggiornano le posizioni di entità e schermo
     */
    public void aggiornaschermo() {
        if (gamestate == statogioca) {
            giocatore.aggiorna();
            npc[0].update();
            npc[1].update();
            npc[2].update();
        }
    }

    /**
     * @brief Disegna i componenti del gioco
     *
     * Disegna il titolo o richiama gli altri metodi per disegnare a seconda
     * dello stato di gioco
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        if (gamestate == statotitolo) {
            ui.draw(g2);
        } else {
            if (backM != null) {
                backM.disegna(g2);
            }
            giocatore.draw(g2);

            for(int i = 0; i < npc.length; i++)
            {
                if(npc[i] != null)
                {
                    npc[i].draw(g2);
                }
            }
            ui.draw(g2);
            g2.dispose();
        }
    }
    
    public void suona(int i)
    {
        suoni.setFile(i);
        suoni.play();
    }
    
    public void fermamusica()
    {
        suoni.stop();
    }
    
    public void suonaES(int i)
    {
        suoni.setFile(i);
        suoni.play();
    }
}
