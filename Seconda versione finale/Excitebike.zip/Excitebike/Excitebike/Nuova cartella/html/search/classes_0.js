var searchData=
[
  ['avversario',['Avversario',['../classentity_1_1_avversario.html',1,'entity']]]
];
