var searchData=
[
  ['background',['background',['../classbackground_1_1_back_manager.html#ac9f2c2791c63836af3b4e5b5e6214787',1,'background::BackManager']]]
];
