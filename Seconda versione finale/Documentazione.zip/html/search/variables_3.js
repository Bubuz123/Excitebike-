var searchData=
[
  ['deaccelerazione',['deaccelerazione',['../classentity_1_1_player.html#a334bda59f0a2e7b6af6d2305be273284',1,'entity::Player']]],
  ['direction',['direction',['../classentity_1_1_entity.html#a79e1f72bd2d70b8a0bd332e6a8abf402',1,'entity::Entity']]]
];
