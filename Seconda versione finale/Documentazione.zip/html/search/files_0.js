var searchData=
[
  ['avversario_2ejava',['Avversario.java',['../_avversario_8java.html',1,'']]]
];
