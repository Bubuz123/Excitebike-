var searchData=
[
  ['pannello_2ejava',['Pannello.java',['../_pannello_8java.html',1,'']]],
  ['player_2ejava',['Player.java',['../_player_8java.html',1,'']]]
];
