var searchData=
[
  ['image',['image',['../classbackground_1_1_background.html#a45e94f786577439d02e4f16aefa96717',1,'background::Background']]],
  ['inizio',['Inizio',['../classexcitebike_1_1_pannello.html#a0e7a84414034add87258d9dc8743d792',1,'excitebike::Pannello']]]
];
