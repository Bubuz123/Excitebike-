var searchData=
[
  ['background',['Background',['../classbackground_1_1_background.html',1,'Background'],['../namespacebackground.html',1,'background'],['../classbackground_1_1_back_manager.html#ac9f2c2791c63836af3b4e5b5e6214787',1,'background.BackManager.background()']]],
  ['background_2ejava',['Background.java',['../_background_8java.html',1,'']]],
  ['backmanager',['BackManager',['../classbackground_1_1_back_manager.html',1,'BackManager'],['../classbackground_1_1_back_manager.html#a2fa2d4af83129b60ef51088d1f080bba',1,'background.BackManager.BackManager()']]],
  ['backmanager_2ejava',['BackManager.java',['../_back_manager_8java.html',1,'']]]
];
