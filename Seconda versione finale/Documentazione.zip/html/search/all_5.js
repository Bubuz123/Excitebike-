var searchData=
[
  ['freno',['freno',['../classentity_1_1_player.html#a25be70e07471ab6a8f8691ff4ada2e8b',1,'entity::Player']]]
];
