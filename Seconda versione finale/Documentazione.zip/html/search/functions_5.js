var searchData=
[
  ['getbackimage',['getBackImage',['../classbackground_1_1_back_manager.html#a7fc55499ca846683c94b4e2c57a15678',1,'background::BackManager']]],
  ['getimage',['getImage',['../classentity_1_1_avversario.html#acd4bd75c24769238f365de299bde96ac',1,'entity.Avversario.getImage()'],['../classentity_1_1_entity.html#acd4bd75c24769238f365de299bde96ac',1,'entity.Entity.getImage()'],['../classentity_1_1_player.html#acd4bd75c24769238f365de299bde96ac',1,'entity.Player.getImage()']]]
];
