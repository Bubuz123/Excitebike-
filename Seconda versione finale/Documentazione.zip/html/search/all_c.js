var searchData=
[
  ['npc',['npc',['../classexcitebike_1_1_pannello.html#af74844aadb763352adb931e8333fdca2',1,'excitebike::Pannello']]],
  ['numcomando',['numcomando',['../classexcitebike_1_1_u_i.html#a145c2986ed6b95f136e6444a670426a3',1,'excitebike::UI']]],
  ['nummappa',['nummappa',['../classbackground_1_1_back_manager.html#ab165c498d35e0726b9015162a309bec7',1,'background::BackManager']]],
  ['numsprite',['numSprite',['../classentity_1_1_entity.html#a785339cb557a3b5cfc8458993629bdfe',1,'entity::Entity']]]
];
