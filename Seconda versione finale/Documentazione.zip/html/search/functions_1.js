var searchData=
[
  ['backmanager',['BackManager',['../classbackground_1_1_back_manager.html#a2fa2d4af83129b60ef51088d1f080bba',1,'background::BackManager']]]
];
