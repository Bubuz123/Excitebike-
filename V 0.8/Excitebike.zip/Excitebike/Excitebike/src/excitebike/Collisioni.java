/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excitebike;

import entity.Entity;

/**
 *
 * @author Newer
 */
public class Collisioni {

    Pannello p;

    public Collisioni(Pannello p) {
        this.p = p;
    }

    public void controllaTile(Entity e) {
        int vel = (int) e.speed;
        int esinistraworldx = e.worldx + e.hitbox.x;
        int edestraworldx = e.worldx + e.hitbox.x + e.hitbox.width;
        int esuworldy = e.worldy + e.hitbox.y;
        int egiuworldy = e.worldy + e.hitbox.y + e.hitbox.height;

        int esinistracol = esinistraworldx / p.Tilesfinali;
        int edestracol = edestraworldx / p.Tilesfinali;
        int esurig = esuworldy / p.Tilesfinali;
        int egiurig = egiuworldy / p.Tilesfinali;

        int numtile1, numtile2;

        switch (e.direction) {
            case "su":
                esurig = (esuworldy - p.Tilesfinali / 2) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][esurig];
                numtile2 = p.backM.grandezzamappa[edestracol][esurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                }
                break;
            case "giu":
                egiurig = (egiuworldy + p.Tilesfinali / 2) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][egiurig];
                numtile2 = p.backM.grandezzamappa[edestracol][egiurig];
                e.collision = true;
                if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                    e.collisiontype = "Rallenta";
                }
                if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                    e.collisiontype = "Normale";
                }
                if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                break;
            case "sinistra":
                esinistracol = (esinistraworldx - vel) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[esinistracol][esurig];
                numtile2 = p.backM.grandezzamappa[esinistracol][egiurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                }
                break;
            case "destra":
                edestracol = (edestraworldx + vel) / p.Tilesfinali;
                numtile1 = p.backM.grandezzamappa[edestracol][esurig];
                numtile2 = p.backM.grandezzamappa[edestracol][egiurig];
                if (p.backM.background[numtile1].collision == true || p.backM.background[numtile2].collision == true) {
                    e.collision = true;
                    if (p.backM.background[numtile1].collisiontype == "Rallenta" || p.backM.background[numtile2].collisiontype == "Rallenta") {
                        e.collisiontype = "Rallenta";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Ostacolo" || p.backM.background[numtile2].collisiontype == "Ostacolo") {
                        e.collisiontype = "Ostacolo";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Normale" || p.backM.background[numtile2].collisiontype == "Normale") {
                        e.collisiontype = "Normale";
                    }
                    if (p.backM.background[numtile1].collisiontype == "Fine" || p.backM.background[numtile2].collisiontype == "Fine") {
                        e.collisiontype = "Fine";
                    }
                }
                break;
        }
    }
}
