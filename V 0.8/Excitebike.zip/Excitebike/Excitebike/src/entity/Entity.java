/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Newer
 */
public class Entity {
    
    public int worldx, worldy;
    public double speed;
    
    public BufferedImage su1, giu1, sinistra1, sinistra2, sinistra3, destra1, destra2, caduta1, caduta2, caduta3, fine; //qua metti tutti gli sprite
    public String direction;
    
    public int contSprite = 0; //dopo un tot switcha lo sprite con animazione
    public int numSprite = 1; //numero sprite
    
    public Rectangle hitbox;
    public boolean collision = false;
    public String collisiontype;
}
