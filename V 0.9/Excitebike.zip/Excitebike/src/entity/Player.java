/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import excitebike.Controlli;
import excitebike.Pannello;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.image.BufferedImage;

/**
 *
 * @author Newer
 */
public class Player extends Entity {

    Controlli controlli;

    public final int screenX;
    public final int screenY;

    public final double accelerazione = 0.9;
    public double velcorrente;
    public final double deaccelerazione = -0.2;
    public final double freno = -0.6;

    public String stato;
    public int contstato;
    public int contfine;

    public int contapenna;
    public int tempopenna;

    public int contacaduta;
    
    public int timer;

    public Player(Pannello pannello, Controlli controlli) {
        
        super(pannello);
        this.controlli = controlli;

        screenX = pannello.larghezzaschermo / 2 - (pannello.Tilesfinali / 2);
        screenY = pannello.altezzaschermo / 2 - (pannello.Tilesfinali / 2); //per mettere il giocatore al centro

        hitbox = new Rectangle(0, 0, pannello.Tilesfinali, 30); //invece di pannello.Tilesfinali metti 32 per collisioni + piccole

        setDefault();
        getImage();
    }

    public void setDefault() {
        stato = "Normale";
        contstato = 0;
        contapenna = 0;
        tempopenna = 0;
        contacaduta = 0;
        contfine = 0;
        velcorrente = 0;
        worldx = pannello.Tilesfinali * 13; //x iniziale (sul map01.txt)
        worldy = pannello.Tilesfinali * 8; //y iniziale
        speed = 10;
        timer = 0;
        direction = "destra";
    }

    public void getImage() {
        try {
            //cambia i vari test con gli sprite (su/giu/destra/sinistra) e le loro animazioni (nel 2)
            //qua assegni ad ogni sprite del player il suo file (mettilo nel package Player dentro res)
            su1 = ImageIO.read(getClass().getResourceAsStream("/player/ridersu.png"));
            giu1 = ImageIO.read(getClass().getResourceAsStream("/player/ridergiu.png"));
            sinistra1 = ImageIO.read(getClass().getResourceAsStream("/player/penna1.png"));
            sinistra2 = ImageIO.read(getClass().getResourceAsStream("/player/penna2.png"));
            sinistra3 = ImageIO.read(getClass().getResourceAsStream("/player/penna3.png"));
            destra1 = ImageIO.read(getClass().getResourceAsStream("/player/rider1.png"));
            destra2 = ImageIO.read(getClass().getResourceAsStream("/player/rider2.png"));
            caduta1 = ImageIO.read(getClass().getResourceAsStream("/player/caduta3.png"));
            caduta2 = ImageIO.read(getClass().getResourceAsStream("/player/caduta2.png"));
            caduta3 = ImageIO.read(getClass().getResourceAsStream("/player/caduta1.png"));
            fine = ImageIO.read(getClass().getResourceAsStream("/player/win.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void aggiorna() {
        /*if(controlli.supremuto == true || controlli.giupremuto == true || controlli.sinistrapremuto == true || controlli.destrapremuto == true)
        {
            
        }*/ //metti tutto qui se vuoi che si aggiorni lo sprite solo quando un tasto è premuto
        if (controlli.supremuto == true) {
            direction = "su";
        } else if (controlli.giupremuto == true) {
            direction = "giu";
        } else if (controlli.sinistrapremuto == true) {
            direction = "sinistra";
        } else if (controlli.accellerapremuto == true) {
            direction = "destra";
        }

        collision = false;
        collisiontype = "";
        pannello.collisioni.controllaTile(this);
        //int npcI = pannello.collisioni.CheckEntity(this, pannello.npc);

        if (stato == "Normale") {
            speed = 10;
        }

        if (contfine != 0) {
            contfine++;
            worldx += 4;
            if (contfine >= 30) {
                stato = "Fine";
                worldx -= 2;
            }
            if (contfine >= 120) {
                pannello.gamestate = pannello.statofine;
            }
        } else {
            timer++;
            if (contacaduta != 0) {
                tempopenna = 0;
                contacaduta++;
                if (contacaduta >= 40) {
                    contacaduta = 0;
                    stato = "Normale";
                }
            }

            if (collisiontype == "Fine") {
                contfine++;
            } else {
                if (collisiontype == "Ostacolo") {
                    stato = "Caduta";
                    contacaduta = 1;
                }

                if (collisiontype != "Normale") {
                    if (stato == "Normale" || stato == "Sinistra1" || stato == "Sinistra2" || stato == "Sinistra3") {
                        if (controlli.supremuto || controlli.giupremuto || controlli.sinistrapremuto || controlli.destrapremuto) {
                            switch (direction) {
                                case "su":
                                    //pannello.suonaES(1);
                                    stato = "Su";
                                    worldy -= pannello.Tilesfinali;
                                    break;
                                case "giu":
                                    //pannello.suonaES(1);
                                    stato = "Giu";
                                    worldy += pannello.Tilesfinali;
                                    break;
                                case "sinistra":
                                    //worldx += speed;
                                    break;
                                case "destra":
                                    //worldx -= speed;
                                    break;
                            }
                        }
                        if (controlli.accellerapremuto) {
                            velcorrente += accelerazione;
                            if (velcorrente > speed) {
                                velcorrente = speed;
                            }
                        } else if (controlli.decellerapremuto) {
                            velcorrente += freno;
                            if (velcorrente < 0) {
                                velcorrente = 0;
                            }
                        } else {
                            velcorrente += deaccelerazione;
                            if (velcorrente < 0) {
                                velcorrente = 0;
                            }
                        }
                    }
                }

                if (velcorrente > 0) {
                    worldx += (int) velcorrente;
                }

                if (collisiontype == "Rallenta") {
                    velcorrente = velcorrente / 2 + 1;
                }

                if (stato == "Su" || stato == "Giu") {
                    contstato++;
                    if (contstato == 10) {
                        stato = "Normale";
                        contstato = 0;
                        direction = "Destra";
                    }
                }

                if ((stato == "Sinistra1" || stato == "Sinistra2" || stato == "Sinistra3") && tempopenna == 0) {
                    tempopenna = 1;
                }

                if (tempopenna != 0) {
                    tempopenna++;
                }

                if (contapenna != 0) {
                    contapenna++;
                    if (contapenna >= 5) {
                        contapenna = 0;
                    }
                }
                if (controlli.sinistrapremuto && contapenna == 0) {
                    contapenna++;
                    if (stato == "Normale") {
                        stato = "Sinistra1";
                        speed = 12;
                    } else if (stato == "Sinistra1") {
                        speed = 15;
                        stato = "Sinistra2";
                    } else if (stato == "Sinistra2") {
                        speed = 18;
                        stato = "Sinistra3";
                    } else if (stato == "Sinistra3") {
                        speed = 10;
                        stato = "Caduta";
                        contapenna = 0;
                        contacaduta = 1;
                    }
                }

                if ((controlli.destrapremuto && contapenna == 0) || tempopenna >= 60) {
                    if (tempopenna >= 60) {
                        tempopenna = 0;
                    }
                    contapenna++;
                    if (stato == "Sinistra1") {
                        speed = 10;
                        stato = "Normale";
                    } else if (stato == "Sinistra2") {
                        speed = 12;
                        stato = "Sinistra1";
                    } else if (stato == "Sinistra3") {
                        speed = 15;
                        stato = "Sinistra2";
                    }
                }
            }
        }

        contSprite++;
        if (contSprite > 10) //cambia il 10 per rallentare animazione
        {
            if (numSprite == 1) {
                numSprite = 2;
            } else if (numSprite == 2) {
                numSprite = 1;
            }
            contSprite = 0;
        }
    }

    public void draw(Graphics2D g2) {
        BufferedImage image = null;

        switch (stato) {
            case "Su":
                image = su1;
                break;
            case "Giu":
                image = giu1;
                break;
            case "Normale":
                if (numSprite == 1) {
                    image = destra1;
                }
                if (numSprite == 2) {
                    image = destra2;
                }
                break;
            case "Sinistra1":
                image = sinistra1;
                break;
            case "Sinistra2":
                image = sinistra2;
                break;
            case "Sinistra3":
                image = sinistra3;
                break;
            case "Caduta":
                if (contacaduta < 10) {
                    image = caduta1;
                }
                if (contacaduta > 10 && contacaduta < 20) {
                    velcorrente = velcorrente / 2 + (velcorrente / 4);
                    image = caduta2;
                }
                if (contacaduta > 20 && contacaduta < 30) {
                    image = caduta3;
                }
                if (contacaduta > 30) {
                    image = caduta1;
                }
                break;
            case "Fine":
                image = fine;
                break;
        }

        int x = screenX;
        int y = worldy - ((pannello.Tilesfinali * 2) + 18); //compensazione manuale di 18

        if (screenX > worldx) {
            x = worldx;
        }
        if (screenY > worldy) {
            y = worldy;
        }

        /*int offsetdestra = pannello.larghezzaschermo - screenX;
            if(offsetdestra > pannello.larghezzaMondo - worldx)
            {
                x = pannello.larghezzaschermo -(pannello.larghezzaMondo - worldx);
            }
            int offsetgiu = pannello.altezzaschermo - screenY;
            if(offsetgiu > pannello.altezzaMondo - worldy)
            {
                y = pannello.altezzaschermo -(pannello.altezzaMondo - worldy);
            }*/
        g2.drawImage(image, x, y, pannello.Tilesfinali, pannello.Tilesfinali, null);
    }
}
