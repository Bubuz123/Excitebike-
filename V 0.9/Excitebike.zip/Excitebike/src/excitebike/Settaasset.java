/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excitebike;

import entity.Avversario;

/**
 *
 * @author Newer
 */
public class Settaasset {
    
    Pannello p;

    public Settaasset(Pannello p) {
        this.p = p;
    }
    
    public void setNPC()
    {
        /*p.npc[0] = new Avversario(p);
        p.npc[0].worldx = p.Tilesfinali * 14;
        p.npc[0].worldy = p.Tilesfinali * 8;*/
    }
}
